﻿using System;
using Network;
using ProtoBuf;
using SapphireEngine;
using SapphireEngine.Functions;
using UnityEngine;
using UServer3.Rust.Data;
using UServer3.Rust.Network;
using UServer3.Rust.Struct;
using BaseNetworkable = UServer3.Rust.BaseNetworkable;
using BasePlayer = UServer3.Rust.BasePlayer;

public class AutoMeleAttack : IPlugin
{
    private bool Enabled = false;
    private BasePlayer TargetPlayer = null;
    private Timer AutoTimer = null;
    
    
    public void Loaded()
    {
        this.AutoTimer = Timer.SetInterval(() =>
        {
            //float distance = 
            BasePlayer.ListPlayers.ForEach(player =>
            {
                if (player != BasePlayer.LocalPlayer && Vector3.Distance(player.Position, BasePlayer.LocalPlayer.Position) <= 3.1f)
                {
                    
                }
            });
        }, 0.1f);
    }

    public void Unloaded()
    {
        this.AutoTimer.Dispose();
    }

    public void OnPlayerTick(PlayerTick playerTick, PlayerTick previousTick)
    {
        
    }

    public bool Out_NetworkMessage(Message message)
    {
        message.read._position = 1; 
        switch (message.type)
        {
            case Message.Type.ConsoleCommand:
            
                string command = message.read.String();

                if (command.Contains("am_enabled") == true)
                {
                    if (command.Contains("1"))
                    {
                        Console.WriteLine("[AutoMeleAttack] Enabled");
                        this.Enabled = true;
                    }
                    else
                    {
                        Console.WriteLine("[AutoMeleAttack] Disabled");
                        this.Enabled = false;
                    }
                    return true;
                }
                break;
        }
        return false;
    }

    public bool In_NetworkMessage(Message message)
    {
        

        return false;
    }

    public void OnPacketEntityCreate(Entity entityPacket)
    {
    }

    public bool OnPacketEntityUpdate(Entity entityPacket)
    {
        return false;
    }

    public void OnPacketEntityPosition(uint uid, Vector3 position, Vector3 rotation)
    {
    }

    public void OnPacketEntityDestroy(uint uid)
    {
    }

    public bool CallHook(string name, object[] args)
    {
        return false;
    }
}